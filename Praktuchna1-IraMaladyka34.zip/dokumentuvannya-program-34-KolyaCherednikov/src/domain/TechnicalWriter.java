package domain;
public class TechnicalWriter extends Artist {
}
