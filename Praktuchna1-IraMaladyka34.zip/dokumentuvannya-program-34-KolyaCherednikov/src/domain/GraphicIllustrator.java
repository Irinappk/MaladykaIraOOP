package domain;
public class GraphicIllustrator extends Artist {
}
